# ScreenResolutionChanger

Automatic screen resolution changer using QRes by Anders Kjersem. I Developed this script basically because I required to change the resolution of my screens almost daily and it was a little bit annoying going to windows settings and stuff so I decided to create this scripts, and why not share them in git? 1love.

## DefResolution.bat
Predefined resolution changer, change values in the file
## InputResolution.bat
Requires user to input the values of resolution
