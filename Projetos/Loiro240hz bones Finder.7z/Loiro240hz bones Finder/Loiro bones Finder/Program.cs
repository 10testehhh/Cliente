﻿using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Drag and drop the dump file onto this executable.");
            return;
        }

        string filePath = args[0];
        if (!File.Exists(filePath))
        {
            Console.WriteLine("File not found!");
            return;
        }

        string dumpContent = File.ReadAllText(filePath);
        string pattern = @"protected ITransformNode (\w+); // (0x\w+)";

        Dictionary<string, string> targetNodes = new Dictionary<string, string>
        {
            { "OLCJOGDHJJJ", "Head" },
            { "MPJBGDJJJMJ", "Root" },
            { "GCMICMFEAKI", "LeftWrist" },
            { "HCLMADAFLPD", "Spine" },
            { "CENAIGAFGAG", "Hip" },
            { "JPBJIMCDBHN", "RightCalf" },
            { "BMGCHFGEDDA", "LeftCalf" },
            { "AGHJLIMNPJA", "RightFoot" },
            { "FDMBKCKMODA", "LeftFoot" },
            { "CKABHDJDMAP", "RightWrist" },
            { "KOCDBPLKMBI", "LeftHand" },
            { "LIBEIIIAGIK", "LeftSholder" },
            { "HDEPJIBNIIK", "RightSholder" },
            { "NJDDAPKPILB", "RightWristJoint" },
            { "JHIBMHEMJOL", "LeftWristJoint" },
            { "JBACCHNMGNJ", "LeftElbow" },
            { "FGECMMJKFNC", "RightElbow" }
        };

        MatchCollection matches = Regex.Matches(dumpContent, pattern);
        Dictionary<string, string> extractedData = new Dictionary<string, string>();

        foreach (Match match in matches)
        {
            string varName = match.Groups[1].Value;
            string offset = match.Groups[2].Value;

            if (targetNodes.ContainsKey(varName))
            {
                extractedData[targetNodes[varName]] = offset;
            }
        }

        Console.WriteLine("Loiro240hz");
        Console.ForegroundColor = ConsoleColor.Yellow;

        foreach (var entry in extractedData)
        {
            Console.WriteLine($"\u001b[32m{entry.Key}\u001b[0m = {entry.Value}");
        }

        Console.WriteLine("Press Enter to exit...");
        Console.ReadLine();
    }
}